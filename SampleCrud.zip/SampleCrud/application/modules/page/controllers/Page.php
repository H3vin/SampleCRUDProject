<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends MY_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model(array('Pages_model'=>'model1'));
    } 

	public function index()
	{
		$data['all_info'] = $this->model1->getAllInformation();
		$this->load->view('main_page',$data);
	}

	public function add_new_info()
	{
		$this->load->view('new_information');
	}

	public function save_information()
	{
		$fname = $this->input->post('fname');
		$lname = $this->input->post('lname');
		$birthday = $this->input->post('birthday');
		$gender = $this->input->post('gender');
		$job = $this->input->post('job');
		$type = $this->input->post('type');
		$salary = $this->input->post('salary');
		$company_name = $this->input->post('company_name');

		$data_personal = array(
			'fname' => $fname,
			'lname' => $lname,
			'birthdate' => $birthday,
			'gender' => $gender
		);

		$id = $this->model1->savePersonalInformation($data_personal);

		$data_job = array(
			'info_id' => $id,
			'name' => $job,
			'type' => $type,
			'company_name' => $company_name,
			'salary_month' => $salary
		);

		$bool = $this->model1->saveJobInformation($data_job);
		if($bool == true){
			echo '<script>alert("Data inserted successfully!")</script>';
		} else {
			echo '<script>alert("There is an error!")</script>';
		}

		header( "refresh:1; url=".base_url() );
	}

	function update_form(){
		$id = $this->uri->segment(3);

		$data['personal_info'] = $this->model1->getPersonalInformation($id);

		$this->load->view('update_information',$data);
	}

	function update_information(){
		$fname = $this->input->post('fname');
		$lname = $this->input->post('lname');
		$birthday = $this->input->post('birthday');
		$gender = $this->input->post('gender');
		$job = $this->input->post('job');
		$type = $this->input->post('type');
		$salary = $this->input->post('salary');
		$company_name = $this->input->post('company_name');
		$id = $this->input->post('id');

		$data_personal = array(
			'fname' => $fname,
			'lname' => $lname,
			'birthdate' => $birthday,
			'gender' => $gender
		);
		$personal_check = $this->model1->updatePersonalInformation($data_personal,$id);

		$data_job = array(
			'name' => $job,
			'type' => $type,
			'company_name' => $company_name,
			'salary_month' => $salary
		);
		$job_check = $this->model1->updateJobInformation($data_job,$id);

		if($personal_check == true && $job_check== true){
			echo '<script>alert("Data updated successfully!")</script>';
		} else {
			echo '<script>alert("There is an error!")</script>';
		}

		header( "refresh:1; url=".base_url() );
	}

	function delete_information(){
		$id = $this->uri->segment(3);

		$delete_check = $this->model1->deleteInformation($id);
		if($delete_check){
			echo '<script>alert("Data deleted successfully!")</script>';
		} else {
			echo '<script>alert("There is an error!")</script>';
		}

		header( "refresh:1; url=".base_url() );
	}
}

