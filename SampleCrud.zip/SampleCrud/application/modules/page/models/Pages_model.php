<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Pages_model extends CI_Model {

    function getAllInformation(){
        $this->db->from('information as i');
        $this->db->join('job as j','i.id = j.info_id');
        return $this->db->get()->result();
    }

    function savePersonalInformation($data){
    	$check = $this->db->insert('information',$data);
    	//check if data has successfully save or not
    	if($check == true){
    		return $this->db->insert_id();
    	} else {
    		return 'error';
    	}
    }

    function saveJobInformation($data){
    	return $this->db->insert('job',$data);
    }

    function getPersonalInformation($id){
    	$this->db->from('information as i');
    	$this->db->where('i.id',$id);
        $this->db->join('job as j','i.id = j.info_id');
        return $this->db->get()->row();
    }

    function updatePersonalInformation($data, $id){
    	$this->db->where('id',$id);
    	$this->db->set($data);
    	return $this->db->update('information');
    }

    function updateJobInformation($data_job,$id){
		$this->db->where('info_id',$id);
    	$this->db->set($data_job);
    	return $this->db->update('job');	
    }

    function deleteInformation($id){
    	$this->db->where('id',$id);
    	$check = $this->db->delete('information');
    	if($check == true){
    		$this->db->where('info_id',$id);
    		return $this->db->delete('job');
    	} else {
    		return 'false';
    	}
    }
}
