<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Sample CRUD Project</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/custom.css')?>">
</head>
<body>

<div id="container">
	<h1 style="text-align: center;">SAMPLE CRUD PROJECT</h1>

	<div id="body">
		<p><h3><a href="<?php echo base_url('page/add_new_info')?>" class="button">Add New Information</a></h3></p>
		<table id="customers">
		  <tr>
		    <th>ID</th>
		    <th>Name</th>
		    <th>Age</th>
		    <th>Birthday</th>
		    <th>Gender</th>
		    <th>Job</th>
		    <th>Type</th>
		    <th>Monthly Salary</th>
		    <th>Company Name</th>
		    <th></th>
		  </tr>
		<?php foreach($all_info as $info){?>
		  <tr>
		    <td><?php echo $info->id;?></td>
		    <td><?php echo $info->fname.' '.$info->lname;?></td>
		    <td><?php 
		    	$birthdate = new DateTime(date("Y-m-d",  strtotime(implode('-', array_reverse(explode('/', $info->birthdate))))));
				$today= new DateTime();           
				$age = $birthdate->diff($today)->y;
 				echo $age;?>	
 			</td>
 			<td><?php echo $info->birthdate;?></td>
 			<td><?php echo $info->gender;?></td>
 			<td><?php echo $info->name;?></td>
 			<td><?php echo $info->type;?></td>
 			<td><?php echo $info->salary_month;?></td>
 			<td><?php echo $info->company_name;?></td>
		    <td><center>
		    	<a href="<?php echo base_url('page/update_form/'.$info->id)?>" class="e_d_button">Edit</a> : 
		    	<button class="e_d_button" id="myBtn_<?php echo $info->id?>">Delete</button>
		    </center></td>

		    <!-- The Modal -->
			<div id="myModal_<?php echo $info->id?>" class="modal">
			  <!-- Modal content -->
			  <div class="modal-content">
			    <span class="close_<?php echo $info->id?> close">&times;</span>
			    <center><h2>Are you sure you want to delete the information of <?php echo $info->fname.' '.$info->lname;?>?</h2></center>
			  </div>
			  <div class="modal-footer">
			    <center><a href="<?php echo base_url('page/delete_information/'.$info->id)?>" class="button_modal" style="background-color: #fd3e3e;">Yes</a><a href=""  class="button_modal" style="background-color: #77d026;">No</a></center>
			  </div>
			</div>

			<script>
			// Get the modal
			var modal_<?php echo $info->id?> = document.getElementById("myModal_<?php echo $info->id?>");
			// Get the button that opens the modal
			var btn = document.getElementById("myBtn_<?php echo $info->id?>");
			// Get the <span> element that closes the modal
			var span = document.getElementsByClassName("close_<?php echo $info->id?>")[0];

			// When the user clicks the button, open the modal 
			btn.onclick = function() {
			  modal_<?php echo $info->id?>.style.display = "block";
			}

			// When the user clicks on <span> (x), close the modal
			span.onclick = function() {
			  modal_<?php echo $info->id?>.style.display = "none";
			}
			</script>
			<!-- End of Modal -->

		  </tr>
		<?php }?>
		</table>
	</div>
</div>


</body>
</html>