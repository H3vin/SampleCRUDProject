<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Sample CRUD Project</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/custom.css')?>">
</head>
<body>

<div id="container">
	<h1 style="text-align: center;">SAMPLE CRUD PROJECT</h1>

	<div id="body">	
		<p><h3><a href="<?php echo base_url()?>" class="button">Show All Information</a></h3></p>		
		<center>
			<form action="<?php echo base_url('page/save_information/')?>" method="post">
				<table class="table_border" style="width:50%; margin-bottom: 20px;">
					<tr>
						<th colspan="2"><h2>Add New Information Form</h2></th>
					</tr>
					<tr>
						<td class="td_design">Firstname: </td>
						<td><input class="textbx_design" type="text" name="fname" placeholder="Firstname"></td>
					</tr>
					<tr>
						<td class="td_design">Lastname: </td>
						<td><input class="textbx_design" type="text" name="lname" placeholder="Lastname">
					</tr>
					<tr>
						<td class="td_design">Birthday: </td>
						<td><input class="textbx_design" type="text" name="birthday" placeholder="Ex. August 08, 1990"></td>
					</tr>
					<tr>
						<td class="td_design">Gender: </td>
						<td><select name="gender" class="textbx_design">
							<option>Male</option>
							<option>Female</option>
						</select></td>
					</tr>
					<tr>
						<td class="td_design">Job/Career: </td>
						<td><input class="textbx_design" type="text" name="job" placeholder="Ex. CEO"></td>
					</tr>
					<tr>
						<td class="td_design">Job Type: </td>
						<td><input class="textbx_design" type="text" name="type" placeholder="Ex. Fulltime, Part-Time"></td>
					</tr>
					<tr>
						<td class="td_design">Monthly Salary: </td>
						<td><input class="textbx_design" type="text" name="salary" placeholder="Ex. 20,000"></td>
					</tr>
					<tr>
						<td class="td_design">Company Name: </td>
						<td><input class="textbx_design" type="text" name="company_name" placeholder="Company Name"></td>
					</tr>
					<tr>
						<td class="td_design" colspan="2"><h4><input type="submit" value="Save New Info" class="button"></h4></td>
					</tr>
				<table>
			</form>
		</center>
	</div>
</div>

</body>
</html>